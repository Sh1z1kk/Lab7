let mySwiper = new Swiper('.swiper-container', {
    slidesPerView: 1,
    spaceBetween: 30,
    loop: true,
    pagination: {
      el: '.swiper-pagination',
      clickable: true,
    },
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
});
const openmenu = () => {
  let menu = document.querySelector(".open_navigate");
  menu.style.display = menu.style.display == "flex" ? "none" : "flex";
}